// Global Variables and Constants
const leftGarage = [];
const maxCapacityPerColumn = 10;
const temporaryDepartures = [];

// DOM Elements
const leftParkingSpacesContainer = document.getElementById("leftParkingSpaces");
const arrivalButton = document.getElementById('arrivalButton');
const departureButton = document.getElementById('departureButton');
const arrivalPopup = document.getElementById('arrivalPopup');
const departurePopup = document.getElementById('departurePopup');
const plateNumberInput = document.getElementById('plateNumber');
const addPlateButton = document.getElementById('addPlate');
const selectPlateDropdown = document.getElementById('selectPlate');
const removePlateButton = document.getElementById('removePlate');
const vehicleLogBody = document.getElementById('vehicleLogBody');
const statusMessage = document.getElementById('statusMessage');

// Regex and Logs
const plateRegex = /^[A-Z]{3}\d{3}$/; // Regex for plate validation
const garagePlates = []; 
const vehicleLogs = {};

// Initialize Parking Spaces
function initializeParkingSpaces() {
    leftParkingSpacesContainer.innerHTML = ""; 
    for (let i = 0; i < maxCapacityPerColumn; i++) {
        const leftSpace = document.createElement("div");
        leftSpace.classList.add("space");
        leftSpace.setAttribute("id", `leftSpace${i}`);
        leftParkingSpacesContainer.appendChild(leftSpace);
    }
}
initializeParkingSpaces();
const leftParkingSpaces = Array.from(document.querySelectorAll(".space"));

// Event Listeners for Arrival and Departure
arrivalButton.addEventListener('click', () => {
    togglePopup(arrivalPopup);
    hidePopup(departurePopup);
});

departureButton.addEventListener('click', () => {
    togglePopup(departurePopup);
    hidePopup(arrivalPopup);
});

// Event Listener for Back Button
document.getElementById('backButton').addEventListener('click', () => {
    window.history.back();
  });

// Update Functions
function updateParkingDisplay() {
    leftParkingSpaces.forEach((space, index) => {
        space.textContent = leftGarage[index] || "";
        space.style.backgroundColor = leftGarage[index] ? "gray" : "black";
    });
}

function updateDropdown(allCars = leftGarage) {
    selectPlateDropdown.innerHTML = `<option value="" disabled selected>Select a car</option>`;
    allCars.forEach(plate => {
        const option = document.createElement("option");
        option.value = plate;
        option.textContent = plate;
        selectPlateDropdown.appendChild(option);
    });
}

function updateVehicleLog(plateNumber, action) {
    if (!vehicleLogs[plateNumber]) {
        vehicleLogs[plateNumber] = { arrivals: 0, departures: 0 };
    }
    vehicleLogs[plateNumber][action === "arrival" ? "arrivals" : "departures"] += 1;
    vehicleLogBody.innerHTML = "";
    for (const plate in vehicleLogs) {
        const row = document.createElement("tr");
        row.innerHTML = `
            <td>${plate}</td>
            <td>${vehicleLogs[plate].arrivals}</td>
            <td>${vehicleLogs[plate].departures}</td>
        `;
        vehicleLogBody.appendChild(row);
    }
}

// Popup Handlers
function togglePopup(popup) {
    popup.classList.toggle('hidden');
}

function hidePopup(popup) {
    popup.classList.add('hidden');
}

// Arrival Logic
addPlateButton.addEventListener("click", function () {
    const plateNumber = plateNumberInput.value.trim();
    if (!plateRegex.test(plateNumber)) {
        alert("INVALID PLATE NUMBER. Use 3 uppercase letters followed by 3 digits (e.g., ABC123).");
        return;
    }
    if (leftGarage.includes(plateNumber)) {
        alert("This plate number is already parked.");
        return;
    }
    if (leftGarage.length >= maxCapacityPerColumn) {
        alert("Parking lot is full.");
        return;
    }
    leftGarage.push(plateNumber); 
    updateDropdown();
    updateVehicleLog(plateNumber, "arrival");
    updateParkingDisplay();
    plateNumberInput.value = "";
    hidePopup(arrivalPopup);
    statusMessage.textContent = `${plateNumber} has arrived.`;
});

// Departure Logic
removePlateButton.addEventListener("click", function () {
    const selectedPlate = selectPlateDropdown.value;
    if (!selectedPlate) {
        alert("Please select a car to remove.");
        return;
    }
    const carIndex = leftGarage.indexOf(selectedPlate);
    if (carIndex === -1) {
        alert("Car not found in the garage.");
        return;
    }
    const temporaryDepartures = [];
    for (let i = 0; i < carIndex; i++) {  
        const tempCar = leftGarage.shift(); 
        temporaryDepartures.push(tempCar);
        updateVehicleLog(tempCar, "departure"); 
    }
    const departingCar = leftGarage.shift();
    updateVehicleLog(departingCar, "departure"); 
    while (temporaryDepartures.length > 0) {
        const reparkedCar = temporaryDepartures.shift();
        leftGarage.push(reparkedCar);
        updateVehicleLog(reparkedCar, "arrival"); 
    }
    updateDropdown();
    updateParkingDisplay();
    statusMessage.textContent = `${departingCar} has departed.`;
    hidePopup(departurePopup);
});
