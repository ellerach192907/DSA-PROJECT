// Global Variables and Constants
// Define the main arrays, constants, and variables used to manage the parking garage
const leftGarage = [];
const maxCapacityPerColumn = 10;
const temporaryDepartures = [];

// DOM Elements
// Cache all necessary DOM elements for interactions, such as buttons, popups, inputs, and displays
const leftParkingSpacesContainer = document.getElementById("leftParkingSpaces");
const arrivalButton = document.getElementById('arrivalButton');
const departureButton = document.getElementById('departureButton');
const arrivalPopup = document.getElementById('arrivalPopup');
const departurePopup = document.getElementById('departurePopup');
const plateNumberInput = document.getElementById('plateNumber');
const addPlateButton = document.getElementById('addPlate');
const selectPlateDropdown = document.getElementById('selectPlate');
const removePlateButton = document.getElementById('removePlate');
const vehicleLogBody = document.getElementById('vehicleLogBody');
const statusMessage = document.getElementById('statusMessage');

// Plate Validation and Logs
// Define the regular expression for plate validation and an object to track arrivals and departures
const plateRegex = /^[A-Z]{3}\d{3}$/; 
const garagePlates = [];
const vehicleLogs = {};

// Initialize Parking Spaces
// Create the parking spaces dynamically based on the max capacity
function initializeParkingSpaces() {
    leftParkingSpacesContainer.innerHTML = ""; 
    for (let i = maxCapacityPerColumn - 1; i >= 0; i--) {
        const leftSpace = document.createElement("div");
        leftSpace.classList.add("space");
        leftSpace.setAttribute("id", `leftSpace${i}`);
        leftParkingSpacesContainer.appendChild(leftSpace);
    }
}
initializeParkingSpaces();
const leftParkingSpaces = Array.from(document.querySelectorAll(".space"));

// Event Listeners for Arrival and Departure
// Attach click event listeners for opening and closing the respective popups
arrivalButton.addEventListener('click', () => {
    togglePopup(arrivalPopup);
    hidePopup(departurePopup);
});

departureButton.addEventListener('click', () => {
    togglePopup(departurePopup);
    hidePopup(arrivalPopup);
});

// Event Listener for Back Button
document.getElementById('backButton').addEventListener('click', () => {
    window.history.back();
  });
  
// Update Functions
// Functions to update the parking display, dropdown menu, and vehicle log dynamically
function updateParkingDisplay() {
    leftParkingSpaces.forEach((space, index) => {
        const reverseIndex = leftParkingSpaces.length - 1 - index;
        space.textContent = leftGarage[reverseIndex] || "";
        space.style.backgroundColor = leftGarage[reverseIndex] ? "gray" : "black";
    });
}

function updateDropdown(allCars = leftGarage) {
    selectPlateDropdown.innerHTML = `<option value="" disabled selected>Select a car</option>`;
    allCars.forEach(plate => {
        const option = document.createElement("option");
        option.value = plate;
        option.textContent = plate;
        selectPlateDropdown.appendChild(option);
    });
}

function updateVehicleLog(plateNumber, action) {
    if (!vehicleLogs[plateNumber]) {
        vehicleLogs[plateNumber] = { arrivals: 0, departures: 0 };
    }
    vehicleLogs[plateNumber][action === "arrival" ? "arrivals" : "departures"] += 1;

    vehicleLogBody.innerHTML = "";
    for (const plate in vehicleLogs) {
        const row = document.createElement("tr");
        row.innerHTML = `
            <td>${plate}</td>
            <td>${vehicleLogs[plate].arrivals}</td>
            <td>${vehicleLogs[plate].departures}</td>
        `;
        vehicleLogBody.appendChild(row);
    }
}

// Popup Management
// Functions to toggle or hide popups for user interactions
function togglePopup(popup) {
    popup.classList.toggle('hidden');
}

function hidePopup(popup) {
    popup.classList.add('hidden');
}

// Arrival Logic
// Handles the process of parking a new vehicle, including validation and updating the display
addPlateButton.addEventListener("click", function () {
    const plateNumber = plateNumberInput.value.trim();

    if (!plateRegex.test(plateNumber)) {
        alert("INVALID PLATE NUMBER. Use 3 uppercase letters followed by 3 digits (e.g., ABC123).");
        return;
    }

    if (leftGarage.includes(plateNumber)) {
        alert("This plate number is already parked.");
        return;
    }

    if (leftGarage.length >= maxCapacityPerColumn) {
        alert("Parking lot is full.");
        return;
    }

    leftGarage.push(plateNumber); 
    updateDropdown();
    updateVehicleLog(plateNumber, "arrival");
    updateParkingDisplay();

    plateNumberInput.value = "";
    hidePopup(arrivalPopup);
    statusMessage.textContent = `${plateNumber} has arrived`;
});

// Departure Logic
// Handles the process of removing a vehicle from the garage, updating the log, and rearranging cars
removePlateButton.addEventListener("click", function () {
    const selectedPlate = selectPlateDropdown.value;

    if (!selectedPlate) {
        alert("Please select a car to remove.");
        return;
    }

    const carIndex = leftGarage.indexOf(selectedPlate);

    if (carIndex === -1) {
        alert("Car not found in the garage.");
        return;
    }

    const temporaryDepartures = [];

    for (let i = leftGarage.length - 1; i > carIndex; i--) {
        const tempCar = leftGarage.pop();
        temporaryDepartures.push(tempCar);
        updateVehicleLog(tempCar, "departure"); 
    }

    const departingCar = leftGarage.pop();
    updateVehicleLog(departingCar, "departure"); 

    const allCars = [...leftGarage, ...temporaryDepartures];

    while (temporaryDepartures.length > 0) {
        const reparkedCar = temporaryDepartures.pop();
        leftGarage.push(reparkedCar);
        updateVehicleLog(reparkedCar, "arrival"); 
    }

    updateDropdown(allCars); 
    updateParkingDisplay();
    statusMessage.textContent = `${departingCar} has departed.`;
    hidePopup(departurePopup);
});